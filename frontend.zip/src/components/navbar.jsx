import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav>
      <Link to="/">Home</Link>
      <Link to="/markets">Markets</Link>
      <Link to="/vendors">Vendors</Link>
      {/* Add other navigation links */}
    </nav>
  );
};

export default Navbar;
