import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>© 2023 Farmers Market Hub</p>
      {/* Additional footer content */}
    </footer>
  );
};

export default Footer;
