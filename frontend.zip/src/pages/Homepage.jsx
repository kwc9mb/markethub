import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to Farmers Market Hub</h1>
      <p>This is the home page of your application.</p>
      {/* Additional content for the home page */}
    </div>
  );
};

export default HomePage;
