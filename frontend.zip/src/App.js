import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/navbar'; // Fix the casing of the file name
import Footer from './components/footer'; // Fix the casing of the file name
import HomePage from './pages/Homepage'; // Fix the casing of the file name
import MarketsPage from './pages/MarketsPage';
import VendorsPage from './pages/VendorsPage';
import NotFoundPage from './pages/NotFoundPage';
// Import other necessary components and pages

function App() {
  return (
    <Router>
      <Navbar />  {/* Your navigation bar */}
      
      <Routes> {/* Switch component to render the first route that matches the location */}
        <Route path="/" exact component={HomePage} />
        <Route path="/markets" component={MarketsPage} />
        <Route path="/vendors" component={VendorsPage} />
        <Route component={NotFoundPage} /> {/* No path means it's a catch-all route */}
      </Routes>

      <Footer /> {/* Your footer */}
    </Router>
  );
}

export default App;
