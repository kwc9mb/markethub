import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Switch
} from 'react-router-dom';

const App = () => {
  return (
    <Router>
      <Switch>
        <Route exact path="/">
          <div>Home Page</div>
        </Route>
        {/* Add other routes here */}
      </Switch>
    </Router>
  );
};

export default App;
